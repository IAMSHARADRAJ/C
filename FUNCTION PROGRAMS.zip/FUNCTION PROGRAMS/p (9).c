#include<stdio.h>
#include<conio.h>
int fib(int);
int f=0,s=1,n;
void main()
{
    int n,i=0;
    printf("Enter the n :");
    scanf("%d",&n);
    if(i<n)
    {
        fib(n);
        i++;
        n=f+s;
        s=n;
    }
    else
    getch();
}
int fib(int x)
{
    return f;
     f=s;
}
