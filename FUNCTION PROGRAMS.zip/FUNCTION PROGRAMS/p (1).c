#include<stdio.h>
int reverse,temp;
int pd(int);
void main()
{
    int a1[100],n,i;
    printf("Enter the limit : ");
    scanf("%d",&n);
    for(i=0;i<=n-1;i++)
    {
        printf("Enter number %d :",i+1);
        scanf("%d",&a1[i]);
    }
    printf("Numbers are : ");
    for(i=0;i<=n-1;i++)
    {
        printf("% d ",a1[i]);
    }

    for(i=0;i<=n-1;i++)
    {
        temp=a1[i];
        int pd(int temp);
        printf("%REVERSE IS %d ",reverse);
    }

    int pd(int x)
    {
        x=temp;
        while(temp!=0)
           {
              reverse=reverse*10;
              reverse=reverse+temp%10;
              temp=temp/10;
           }
           return reverse;
    }
getch();
}
